# Validation for the 9 October submission candidate

## Current-base checks

CP develop is pinned to 3a03be8902479c4240f083aec4e7f61562a4beb2.
Its SDK gitlink remains 425d200a8ea447326b4b9696e4e47dc84ad9d7f6.
Two upstream commits since the O60 base changed four unrelated files;
none intersects this candidate's owned result paths.

The complete source series reconstructed from public refs in 5.038 seconds.
Patch/result hashes and git diff --check passed. The 38-path ownership diff
was also applied independently to its explicit prerequisite tree, producing
the same final hashes. A check on raw develop fails because prerequisites
are absent; that is an intentional dependency proof, not a claim of a clean
standalone PR against today's raw base.

The implementation and test result hashes match O60, including its actual
TrustedTime ASan/UBSan run and old-cap negative control. Those green host
checks were not repeated. No TLS, timer, decoder or SD implementation changed
in this rebase. Earlier four-axis logical reviews are reused only over the
same code; a new independent review checked submission scope and topology.
The three clock/caller C++ files pass clang-format 23's dry check.

## Firmware build

One final X4 Pro build of the full composed G2 passed in 75.807 seconds,
with two jobs/nice 10, zero retry, 972 CP/890 SDK sources unchanged and 20 own
SDK links. The temporary cache override was removed. The compiled SDK
capability returns true. Private firmware SHA-256:
`97051b4eb2581ca38ae283ceeacb6f0c57c8903c15c61d5347997db1514e0990`. No BIN is included.

## What this does not prove

Source replay and a build do not qualify hardware, the complete service,
C3 peak heap, Power timing, energy, long-run behavior or other model support.
DEVICE-NOTES.en.md describes two separate older private images, not this
candidate. The existing 15-second budget remains cooperative, not a hard
DNS/TCP bound. No new device test, CI or public operation ran for this cycle.

SDK/API acceptance, prerequisite integration, the periodic networking/HAL
scope decision, human authorship/maintenance and required hardware signoff
remain separate. This is a dependent review packet, not MERGE_READY or an
official release. See HUMAN-HANDOFF.en.md before preparing a PR.
