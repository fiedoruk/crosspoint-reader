# Exact prerequisite boundaries

The source series pins public CP/SDK/ArduinoJson refs in series.json. The CP
SDK gitlink is preserved. The SDK patch is a separately identified proposal,
not an accepted upstream ref.

W06 ownership begins after W04(checked BMP) and W05(bounded event work).
Its consolidated change is patches/03-verified-plugin-events.diff. The full
TIMED ownership begins after W06, the existing author's PR3820 timer and W08
bundle installation. In the full series its own change is
patches/07-full-timed-panel.diff. The time adjustment is already included;
there is no third clock-only submission.

These are two review scopes. A PR against raw develop before prerequisites
merge would contain their changes too, rather than a clean37/38-path diff.
Prefer clean PRs once those bases exist and scope/human gates are satisfied.
If a dependent draft is explicitly chosen, disclose its wider actual diff
and remove prerequisites after their merge. Do not treat a fork integration
branch or synthetic tree as an official upstream base.

PR3907/W04, PR3908/W05, PR3916/W08, PR3820/timer and SDKPR65 were OPEN in the
9 October readback. A timer author's acknowledgment is coordination evidence,
not approval of the full background-network consumer by a CP maintainer.
The old Discussion3900 concerns ordinary wake, not this required TIMED path.
