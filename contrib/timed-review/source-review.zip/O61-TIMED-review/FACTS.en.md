# Full TIMED caller — facts for the human author

These are review notes, not a pull-request description or checked attestations.

- Purpose: consume the existing optional timer primitive for one explicitly
  configured SD sleep.timer handler while the reader is not being used.
- Own change: 38 CP paths in TIMED.diff. W06, W04/W05, Michael Kazakov's
  (@kivarun) PR #3820 timer and W08 bundle installation are prerequisites,
  rather than new timer or installation implementations owned by this change.
- Base: current CP develop3a03be89 plus those exact prerequisites. This clean
  ownership diff is not directly applicable to raw develop. A draft against
  raw develop would also show prerequisite changes and require later cleanup.
- Supported caller route: X4 Pro and Sticky; PaperMono requires a different
  RTC/PMIC adapter. C3 timer support in the author's prerequisite does not
  imply support for this full caller.
- Cycle: one snapshot of handler/config/grant, saved Wi-Fi, fresh time,
  verified fetch, complete BMP decode, checked replacement, one panel update,
  timer rearm and sleep. It does not replay reader outboxes or save book state.
- Wi-Fi join has its own 10-second window; fresh time can use up to10 seconds
  within the existing 15-second cooperative attempt budget. Late time sync
  can leave too little time for fetch. DNS/TCP and hardware work may overrun.
- Power uses the HAL capture and existing reader/recovery route. The final
  check-to-sleep race, physical button behavior and energy remain unqualified.
- Image contract: native default Portrait/BW, not complete saved Custom
  rotation/grayscale parity. Last-good pixels can remain during errors;
  image timestamps must not imply a fresh fetch that did not happen.
- O59 private bench observations are separate from this new source candidate
  and its new build. See DEVICE-NOTES.en.md; no new DEVICE result is claimed.
- Scope is unresolved: SCOPE.md restricts active connectivity/background
  Wi-Fi; ROADMAP.md describes later SD plugins. Existing sleep.enter and
  the timer author's acknowledgment are not maintainer approval of this
  periodic native networking/HAL consumer. Obtain that decision before
  presenting the feature as accepted scope.
- No service, renderer, account, image template or firmware binary is included.
  AI tools assisted the code, tests, reviews and factual notes.
