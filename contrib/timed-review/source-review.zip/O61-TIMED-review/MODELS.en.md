# Model qualification

| Model | Caller status | What remains |
|---|---|---|
| X4 Pro | Enabled in source; selected local build profile | Physical Power, panel, heap, energy and repeated cycles |
| Sticky | Enabled by its own SDK profile and GPIO/power contract | Its own device acceptance; X4 Pro build is not proof |
| PaperMono | Not enabled | RTC/PMIC cold-boot adapter, source classification before flag clearing, Power/BOD/device proof |
| C3 X4/X3 | Current author's timer primitive policy preserved | Full caller remains disabled; no C3 heap qualification |

The current image contract is default Portrait480×800 for Sticky/X4Pro and BW
projection into the existing framebuffer. Saved Custom orientation/grayscale
settings are preserved but not fully applied by this separate path. No new
layout, font, LUT or renderer is part of this change.

M5Stack documents RX8130 RTC waking the PaperMono PMIC, which restores ESP power:
https://docs.m5stack.com/en/arduino/papermono/m5pm1_m5ioe1
The manufacturer's source reference is:
https://github.com/m5stack/M5PaperMono-PowerDemo/tree/cf4f57c638aa3ad0168bf90beebdaa3599203bb2
Those measurements are not CP or this device's measurements.

At SDK425d200, Rtc exposes wall-clock operations, not checked wake arm/cancel.
PaperMonoBoard::ensureBooted clears the PMIC wake source. A future adapter needs
to preserve the cause before clearing it, safely program/cancel the external RTC
and retained rails, roll back partial failures, and classify a verified PMIC
restart separately from ESP deep-sleep Timer. Reuse the manufacturer's existing
interfaces with attribution; do not guess pins or disable brownout detection.

A hardware trial must cover USB and battery, failed I2C/alarm arming, removal of
the handler, Power/recovery, retained pixels and current draw. Only after this
qualification should the caller's model gate be extended. No such adapter or
hardware operation is included here.
