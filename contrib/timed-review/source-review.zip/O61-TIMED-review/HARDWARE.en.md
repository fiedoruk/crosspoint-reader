# Hardware test plan — not performed

Use one identified X4 Pro first, with a separately approved operation, backup,
known restore path and pinned CP/SDK source hashes. A local test firmware is
validation material, not a product distribution.

1. Install one synthetic handler in an official plugin root with a valid CA,
   test grant, saved Wi-Fi and a900-second cadence. Sleep while a known book
   position and settings are saved. Observe at least three complete autonomous
   wake/fetch/display/rearm/sleep cycles, including one updated image.
2. At the server, correlate each request with its intended device. Confirm
   peer verification and no unexpected reader outbox or book metadata traffic.
3. Remove network, revoke the grant, use wrong hostname/CA, fail SNTP and send
   malformed/truncated images. Before commit, retain the old asset/pixels;
   do not enter a busy loop or show an error UI on the sleeping panel.
4. Press and release Power during Wi-Fi join, sync, TLS, SD writes, decode,
   commit/display and teardown. Check click/hold preference, later held presses,
   recovery, and the final check-to-sleep window. Confirm native reading resumes.
5. Update the bundle in each supported SD root: preserve grant/config/book state,
   read changed config next cycle. Remove the handler: clear the timer and stop
   rearming. Multiple owners or incomplete configuration must not initiate work.
6. Test low battery around20%, USB insertion/removal and timer-arm failure.
   Confirm the normal sleep and manual wake paths still work.
7. Measure peak internal heap/largest block, stack margin, Wi-Fi/TLS duration,
   SD/EPD timing, energy and NVS updates/erase activity. Repeat the same fixture
   on the baseline; test chosen cadence rather than infer lifetime from a build.

Sticky needs separate acceptance. PaperMono and C3 full-caller support are not
claimed. Gray/rotation/custom-image parity also requires a separate screen trial.
The image should show its data timestamp: old pixels can remain after revocation.
These are instructions for a later authorized hardware handoff, not completed
checks or permission to flash a device.
