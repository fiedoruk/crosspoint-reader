# Human handoff before opening a CrossPoint PR

The two ownership diffs, prerequisite trees and factual notes are ready for
review. Source preparation is not an attestation by the human author.

CrossPoint's current AGENTS.md and firmware-handoff guide require the human
to review the behavior and architecture, explicitly accept maintenance
ownership, write the PR description and complete the required hardware
acceptance before opening a PR. Their template also asks for coordination
when SDK/HAL/bootloader/OTA/recovery boundaries change. None of these fields
has been checked on the author's behalf.

The proposed route is two clean CP PRs after the prerequisite bases are
integrated and the relevant scope gates are resolved. Code remains available
for dependent review before SDK acceptance; accepted SDK/API is a merge and
enablement gate, not a claim that local work or review must wait. A draft
against raw develop contains a wider real diff than37/38 files and must be
labelled accordingly. Do not open a third incidental clock PR.

One focused coordination point is whether a disabled-by-default, SD-owned,
S3-qualified timer consumer belongs to the allowed plugin runtime despite
the active-connectivity restriction. Supply the actual TIMED diff and its
bounded bench facts. This is a scope decision, not a request for another
broad audit. No message has been sent.

## Concrete remaining hardware acceptance

Use the exact eventual candidate and one explicitly qualified model, retain
rollback/settings, and keep the previous image identifiable. Observe normal
reading and sleep; then one opt-in timer fetch, a network failure and503,
Power click/hold during join/fetch/panel/teardown, and return to reading.
Watch for lost progress/settings, boot loops, incorrect Power recovery,
partial image replacement, unintended full wakes or failure to rearm.
Test the supported image contract and any claimed orientations separately.
Record peak heap, time awake and energy over the selected cadence; USB power
and S3 observations do not qualify battery life or C3 heap. PaperMono remains
outside this caller until its RTC/PMIC route is independently qualified.

Existing O59 automation observed a limited private test image, not this new
firmware's complete human acceptance. Do not check full hardware acceptance
from a successful build, source replay, screenshot or those older hashes.
