# Dependent CrossPoint source review — 9 October 2026

Start with patches/07-full-timed-panel.diff: 38 owned CP paths after W06, timer #3820 and W08.
The complete series supplies exact prerequisite patches and an explicit SDK
proposal, rather than hiding dependencies in a private branch. Base CP is
3a03be8902479c4240f083aec4e7f61562a4beb2; its SDK pin remains 425d200.
The older implementation and resulting owned-file hashes are unchanged from
O60. The two intervening upstream commits touch four other files.

This is a source review package, not an SD application or firmware release.
The own diff is not applicable to raw develop until its prerequisites exist.
See FACTS.en.md, HUMAN-HANDOFF.en.md and VALIDATION.en.md for scope, exact
checks, responsibility and evidence limits. No PR description is provided.

## Reproduce in a new directory

Requirements: Git, Python 3; C++20 with ASan/UBSan for tests; CMake for the
TIMED test set. The destination must not already exist.

```sh
python3 reproduce.py ../source-review
python3 reproduce.py ../source-review-with-tests --test
```

The first command fetches exact public refs, applies every locked patch and
checks resulting files. The second also runs the documented host checks,
including TrustedTime. It does not build firmware, publish or touch a device.
For optional actual SDK TLS integration, use the unchanged --wolf-root option
with Arduino-wolfSSL 5.7.2 sources and Python cryptography. That path uses
bounded loopback fixtures; it is not a physical display or Wi-Fi test.

## Provenance and boundaries

The timer primitive remains Michael Kazakov's (@kivarun) work in PR #3820.
SDK #65 verification retains Sameh Foulad's (@sfoulad) credit. The capability API
is still proposed, not accepted. CP's SDK gitlink is not changed by this CP
contribution. CP-derived code uses LICENSE-CP; SDK changes retain LICENSE-SDK
and NOTICE-SDK. Other dependencies keep their original licenses.

AI tools assisted code, tests, reviews and factual notes. Private services,
accounts, renderers, templates, bench harnesses and firmware binaries are not
included. DEVICE-NOTES.en.md records contextual private-image observations
and does not qualify a new binary. No public operation is authorized by
possessing this package.
