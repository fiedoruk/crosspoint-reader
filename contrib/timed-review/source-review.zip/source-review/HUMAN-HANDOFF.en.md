# Before a separate consumer PR

These files provide source and validation facts. They are not a pull-request
description or an attestation written on the human author's behalf.

The owner has acknowledged the existing design and maintenance responsibility.
This revision retains that design. SDK/API acceptance, CP's periodic-networking
scope and the required hardware acceptance are still open. The human author
owns the PR description and the decision to submit it.

Use the eventual exact candidate for device acceptance. Check ordinary reading
and sleep, an opt-in timer fetch, offline and HTTP 503 last-good behavior,
Power click/hold during join/fetch/panel/teardown, recovery and return to reading.
Watch for lost progress, repeated restarts, partial image replacement, unwanted
full wakes and failure to rearm. Test each claimed orientation separately.
Record peak heap, awake time and energy at the chosen cadence. USB-powered
observations do not qualify battery life, and S3 results do not qualify C3 heap.

PaperMono needs its own RTC/PMIC path and qualification. A successful build,
host test or older bench image does not complete these hardware checks.
