# Prerequisites and ownership

`series.json` pins public CP, SDK and ArduinoJson commits. The firmware's SDK
gitlink is preserved. The SDK patch is an explicit proposal applied above
that pin, not a claim that the official SDK already has the API.

| Proposed CP change | Prerequisites | Own diff |
|---|---|---|
| Verified plugin HTTP | Checked BMP (#3907), bounded event work (#3908), proposed SDK verification support (#65) | `patches/03-verified-plugin-events.diff` |
| Full timed consumer | Verified HTTP, Michael Kazakov's timer (#3820), correct bundle installation | `patches/07-full-timed-panel.diff` |

The series uses #3916 for bundle installation. Equivalent behavior from #3877
could replace it after integration; both implementations are not required.
The time changes are part of verified HTTP, not a separate clock-only proposal.

These are two dependent review scopes. Opening either against raw develop
before its prerequisites are integrated would also expose those changes.
A clean PR needs the appropriate base and the required scope and hardware
acceptance. The timer primitive can be reviewed and merged independently.

The prerequisite PRs were still open in the 11 October readback. SDK API/ref
acceptance and CP's periodic networking/HAL decision remain open. An
acknowledgment from the timer author does not settle the consumer's scope.
