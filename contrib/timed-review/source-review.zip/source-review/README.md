# PaperMono RTC wake for timed sleep panels

PaperMono turns off the ESP32 through its M5PM1 PMIC. An ESP deep-sleep timer
cannot wake that powered-off processor. This proposal connects the RX8130
countdown interrupt to PMIC GPIO0 wake, then uses the existing dependent timed
panel caller after a qualified cold boot.

The new changes are the last two patches:

- `08-sdk-papermono-rtc.diff`: checked RTC countdown arm/cancel/event reads,
  RX8130 register-map correction, retained PMIC wake provenance and GPIO0 route.
- `09-cp-papermono-timed.diff`: HAL qualification, PMIC Power capture,
  board-specific shutdown/recovery, and reuse of the shared TIMED caller.

Patches 01–07 are the preceding review series, unchanged. This is dependent
source material, not a clean standalone PR against develop or a released feature.
No firmware binary, private fixture, backend, renderer or credentials are included.

## Reproduce

Use Git and Python 3, with a new output directory:

```sh
python3 reproduce.py ../papermono-review
```

The script fetches pinned public CP/SDK commits, applies nine patches and checks
every listed output hash. CP is `d1f5d1eca4a114086c88d4764a66b7703a1c626c`;
SDK is `32a265fa86498c014e13a5bc16133bb021cb620c`. The SDK proposal is applied
locally; the CP gitlink is not advanced to an unaccepted SDK revision.

For host tests, add `--test`. Requirements include a C++20 compiler with
ASan/UBSan and CMake; the script fetches pinned ArduinoJson and googletest.
To run only the new hardware-adapter tests after reconstruction:

```sh
cd ../papermono-review/crosspoint
python3 freeink-sdk/libs/hardware/Rtc/test/host/run.py
python3 test/papermono_timer/run.py
```

Firmware compilation uses the repository's `papermono` environment. Host tests
simulate bus responses and faults; they do not demonstrate a physical wake.
See `VALIDATION.en.md` for the measured scope and remaining hardware gates.

## Ownership and sources

Michael Kazakov (@kivarun) authored the timer primitive in CP PR #3820.
The SDK verification work comes from Sameh Foulad (@sfoulad), SDK PR #65.
CP and SDK code retain their respective license and notice files in this packet.

The RTC register map and countdown sequence were checked against the
[RX8130CE datasheet](https://m5stack-doc.oss-cn-shenzhen.aliyuncs.com/1132/RX8130CE_cn-Register-Datasheet.pdf).
PMIC register semantics were checked against the
[M5PM1 datasheet](https://m5stack-doc.oss-cn-shenzhen.aliyuncs.com/1207/M5PM1_Datasheet_EN.pdf).
The retained LDO route follows the
[M5Stack PaperMono RTC wake example](https://docs.m5stack.com/en/arduino/papermono/m5pm1_m5ioe1).
[M5Stack PowerDemo](https://github.com/m5stack/M5PaperMono-PowerDemo/tree/cf4f57c638aa3ad0168bf90beebdaa3599203bb2)
was used as a reference for wake sequencing; its different rail policy and
standby measurements are not claimed for this implementation.

AI tools assisted implementation, tests, review and documentation. New RTC/PMIC
behavior still needs explicit human design/maintenance acceptance before a PR.
