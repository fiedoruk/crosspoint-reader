# Verified plugin HTTP and timed sleep — source series

This series reconstructs two proposed CrossPoint changes on CP
`26ccbe2816dd8a9b2b4f5c89ffaac6f1afbdaedd` and its SDK pin
`32a265fa86498c014e13a5bc16133bb021cb620c`.

- `patches/03-verified-plugin-events.diff`: verified HTTP requests, downloads
  and token refresh, after the checked-BMP and event-budget prerequisites.
- `patches/07-full-timed-panel.diff`: an opt-in, SD-configured timer consumer,
  after verified HTTP, the existing timer primitive and bundle-installation fix.

The separate SDK patch includes a proposed capability method. It is not part
of the official SDK revision above. Both CP diffs need their prerequisites;
they do not apply independently to raw develop.

## Reproduce

Requirements: Git and Python 3. Host tests also need a C++20 compiler with
ASan/UBSan and CMake. Use a new destination directory.

```sh
python3 reproduce.py ../timed-review
python3 reproduce.py ../timed-review-tests --test
```

The script fetches pinned public commits, applies the patches and checks
result hashes. `--test` runs the host suites. It does not build firmware,
flash a device or contact a production service. For the optional TLS tests,
pass `--test --wolf-root /path/to/Arduino-wolfSSL` using version 5.7.2 and
install Python's `cryptography` package. Test certificates and keys are
created temporarily for loopback connections.

See `VALIDATION.en.md` for executed checks, `DEPENDENCIES.en.md` for prerequisite
boundaries and `MODELS.en.md` for device limitations. `DEVICE-NOTES.en.md`
records older, separate bench images; it does not qualify this candidate.

Michael Kazakov (@kivarun) authored the timer primitive in PR #3820.
The SDK verification work comes from Sameh Foulad (@sfoulad), SDK PR #65.
CP-derived code retains LICENSE-CP; SDK changes retain LICENSE-SDK and
NOTICE-SDK. Other dependencies retain their own licenses.

AI tools assisted implementation, tests, review and these notes. No firmware
binary or service implementation is included.
