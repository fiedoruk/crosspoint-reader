# Validation — 11 October 2026

The source is pinned to CP `26ccbe28` and SDK `32a265f`, with the SDK proposal
applied explicitly. It was reconstructed from public refs in fresh directories;
all patch/result hashes and `git diff --check` passed.

## Executed checks

- Six host groups: fresh time, wake guard, timer arming, TIMED, verified HTTP
  and event budget. Relevant native paths ran with ASan/UBSan.
- 16 CTest cases covering wake classification and bundle installation.
- Eight cases executing the production wake-hold expression. A negative
  control removing the Metalio exception was rejected by the same test.
- 12 actual SDK TLS cases and four TIMED/TLS/BMP cases on POSIX loopback,
  including wrong-host rejection and failure/last-good behavior.
- SDK Pro, Sticky and Metalio display tests using a recording bus. Their
  CONFIG_PM_ENABLE=0 stubs do not execute the new SDK PM-lock branch.
- One X4 Pro firmware build of the composed series. The source did not change
  during the build, and the compiled SDK capability method returns true.

Linker usage was 104,592/327,680 bytes of RAM and 5,959,050/6,553,600 bytes of
application flash. This is static usage, not a runtime heap measurement.
The build retains the pre-existing wolfSSL
`NO_WOLFSSL_ESP32_CRYPT_RSA_PRI` redefinition warning. Configuration and
wolfSSL settings match the previous build; no warning suppression was added.

Firmware SHA-256:
`39417db8544c240f2623ea17198d160cc42fe453712f21768437c55e7c16c213`.
The binary is not distributed here.

## Not covered

There was no new device test. Physical Power timing, the final check-to-sleep
window, controller variants, energy, peak heap and long-running cycles remain
unqualified for this candidate. Loopback does not exercise Wi-Fi or SNTP.
Older X4 Pro observations in DEVICE-NOTES.en.md use different images.

PaperMono remains disabled. The consumer does not claim full saved Custom
orientation/grayscale parity. SDK API acceptance, periodic-networking scope,
prerequisite integration, required human PR/device acceptance and an official
release are still separate gates.
