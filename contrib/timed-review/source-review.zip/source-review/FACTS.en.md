# Timed consumer — implementation notes

The proposed consumer uses one SD-declared `sleep.timer` handler while the
reader is idle. Its diff is `patches/07-full-timed-panel.diff`, covering 38 CP
paths after the prerequisites listed in `DEPENDENCIES.en.md`.

A qualified timer wake loads the handler and saved Wi-Fi credentials, obtains
fresh time, fetches a BMP over verified TLS, decodes it completely, replaces
the previous file, updates the panel and returns to sleep. It does not drain
reading-event outboxes or save book state. Power can transfer control back to
the normal reader path; physical timing at the final handoff to sleep still
needs testing.

Wi-Fi join has a separate 10-second window. Fresh time can use up to 10 seconds
within the shared 15-second attempt budget. DNS/TCP and hardware calls may
exceed that cooperative budget. A late clock sync can leave no time to fetch.

This revision preserves upstream Metalio cold-boot, wake-hold and power-off
behavior. Metalio is not enabled for the full consumer. The existing host test
now checks the actual wake-hold expression in eight cases. Its stale 5-second
clock-timeout expectation was corrected to match the existing 10-second caller.
The verified transport and SDK proposal are unchanged.

The consumer is enabled in source for X4 Pro and Sticky only. Its image
contract is native Portrait/BW; it does not apply every saved Custom rotation
or grayscale preference. Failures can leave old pixels on the screen, so
image timestamps must accurately describe the content's age. PaperMono needs
a separate RTC/PMIC wake path and remains disabled.

The SDK capability API and CP scope for periodic networking remain unaccepted.
This is material for reviewing the consumer separately from the timer primitive.
No account system, renderer or service-specific connector is part of the diff.
